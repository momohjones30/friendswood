# project
schoolproject
A school website with in-built quiz application.
