from .base import *

SECRET_KEY = 'ABC'

DEBUG = True

ALLOWED_HOSTS = []